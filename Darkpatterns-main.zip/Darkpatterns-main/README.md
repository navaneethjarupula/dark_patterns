"The rights of this project belong to The team Dark Guardians of GCET.
Everyone is granted the right to use, modify, and distribute this code 
under the condition that they use reference 'no1hkg' in their project.
The purpose of this condition is to respect the privacy and distinct identity
of 'no1hkg' in any derivative works or projects.
All users are encouraged to freely utilize and adapt the code for their purposes,
ensuring compliance with the established conditions. This permission includes both 
personal and commercial use, provided that the usage adheres to ethical and legal standards.

By using this code, users acknowledge the ownership of The team Dark Guardians of GCET
and agree to adhere to the specified conditions. The team reserves the right to modify these
conditions at any time and expects users to stay informed about any updates.

This open approach is aimed at fostering collaboration, innovation, and the sharing of knowledge 
within the community while respecting individual preferences regarding attribution."

$$$$$$$$$$$$$$$$$$$$$$ HOW TO USE $$$$$$$$$$$$$$$$$$$$$$$$$$$$$

####firstly create a python environment in anaconda(recomanded)//Pycharm#####
-----@-----
add libraries to your 
#pandas
#requests
#bs4
#jasonify
-----@-----
add the ext folder to your environment
-----@-----
go to chrome --->extension---->turn on developer mode----->load unpacked----->select ext folder
------@-----
go to your python environment
run app.py file
deployment server turns on 
goto chrome browsser---->click on extension----->detect dark patterns--->""wait for a While""
the dark patterns will be displayed.
##########end########
